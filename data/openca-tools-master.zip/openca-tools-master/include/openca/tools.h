/* OpenCA PKCS#7 tool - (c) 2000 by Massimiliano Pala and OpenCA Group */

/* OpenSSL Definitions */
#include <openssl/bio.h>

/* Functions Definitions */
int getCommand( int argc, char *argv[] );
void printVersion( BIO *bio_err, char *INFO[] );

/* External Variables */
