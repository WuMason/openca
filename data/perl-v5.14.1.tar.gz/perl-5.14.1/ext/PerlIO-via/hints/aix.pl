# compilation may hang at -O3 level
$self->{OPTIMIZE} = '-O';
